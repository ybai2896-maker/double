"""Batch export the supplied SEM images using the supplied V7.5 evidence algorithm.
All masks/ROI matches are candidates; this script never claims human approval.
"""
import sys, json, csv, io, shutil, hashlib, zipfile, html
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import engine, advanced as A, review_engine as R, manual_editor as M
import model_export as ME, parameter_tools as PT, roi_physical as PH

ROOT=Path('/workspace/sem_work')
OUT=Path('/workspace/sem_results/SEM_results')
OUT.mkdir(parents=True,exist_ok=True)
RAW=ROOT/'raw'
XLS=Path('/workspace/attachments/5989851c-2e6b-421f-b021-65012eeeb6b3/1.2.xlsx')
records=engine.parameter_rows(XLS.read_bytes(),XLS.name)
original_records={r['原文件名']:dict(r) for r in records}
rows={r['原文件名']:dict(r) for r in records}
power_key=next(k for k in rows['1-45.tif'] if PT.identify(k)=='fs_power_mw')
rows['1-45.tif'][power_key]=0.515
centers_all=json.loads((ROOT/'inspection/centers.json').read_text())
GROUPS=[(2,None,3),(4,5,6),(9,8,7),(12,11,10),(15,14,13),
        (18,16,17),(21,19,20),(24,22,23),(27,26,25),(30,28,29),
        (33,31,32),(36,34,35),(39,37,38),(42,40,41),(45,43,44)]
# For the double-edge 1-11 view the central ridge is y=764, not the outer bright rim.
ZOOM_CENTERS={5:716,8:719,11:764,14:793,16:754,19:800,22:802,
              26:777,28:781,31:772,34:775,37:761,40:757,43:766}
REFERENCE_LABELS={1:[1396,1451],2:[160.5,1123],3:[202.4],4:[195.4],5:[139.6],
                  6:[146.5],7:[146.5],8:[502.4],9:[509.4],10:[488.5],
                  11:[334.9],12:[467.5],13:[328.0],14:[314.0],15:[300.1]}

def jwrite(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def cwrite(path,rows,fields=None):
    if fields is None: fields=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for row in rows:w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in row.items() if k in fields})

def image(n):
    name=f'1-{n:02d}.tif';raw=(RAW/name).read_bytes()
    return name,raw,engine.grayscale_image(raw),engine.metadata_of(raw)

def local_grid(mask,nm,centers):
    # Unlike the UI's aggregate centroid between four lines, anchor on one observed
    # foreground pixel so a four-line mask does not produce an empty local grid.
    chosen=2 if len(centers)>2 else 0
    center=centers[chosen]
    yy,xx=np.nonzero(mask)
    eligible=np.abs(yy-center)<min(100,max(15,650/nm))
    if not eligible.any():eligible=np.ones(len(xx),bool)
    ey,ex=yy[eligible],xx[eligible]
    if len(ex):
        mid=np.median(ex);k=int(np.argmin((ex-mid)**2+0.05*(ey-center)**2))
        cx,cy=float(ex[k]),float(ey[k])
    else:cx,cy=(mask.shape[1]-1)/2,float(center)
    gx=cx+(np.arange(100)-49.5)*20/nm;gy=cy+(np.arange(80)-39.5)*20/nm
    xi,yi=np.meshgrid(gx,gy)
    grid=(ndi.map_coordinates(mask.astype(float),[yi,xi],order=0,mode='constant',cval=0)>127).astype('uint8')*255
    return grid,{'step_nm':20,'shape_yx':[80,100],'anchor_xy_image_px':[cx,cy],
                 'anchor_detected_line_index':chosen+1,'anchor_is_zoom_correspondence':False,
                 'physical_extent_um':[2.0,1.6],
                 'meaning':'local binary mask resampling only; not optical PSF, PDE or measured registration'}

def line_midpoint(gray,centers,pixel_nm,length_um):
    """Avoid shifting midpoint to one bright remnant when a line is faint."""
    aa=gray.astype(float);hp=aa-ndi.gaussian_filter(aa,(15,1))
    v=np.mean([np.mean(np.abs(hp[max(0,y-25):y+26]),axis=0) for y in centers],axis=0)
    v=ndi.gaussian_filter1d(v,10)
    bg=float(np.median(np.r_[v[:40],v[-40:]]))
    active=v>bg+.22*(float(np.quantile(v,.9))-bg)
    bounds=np.flatnonzero(np.diff(np.r_[False,active,False]))
    runs=[(int(a),int(b)) for a,b in zip(bounds[::2],bounds[1::2]) if b-a>50]
    if not runs:return (gray.shape[1]-1)/2,{'method':'image center fallback','precise':False}
    left,right=max(runs,key=lambda p:p[1]-p[0]);nominal=length_um*1000/pixel_nm
    method='aggregate visible line texture endpoints'
    if right-left<nominal*.8:
        left=max(0.,right-nominal)
        method='low contrast fallback: nominal design length anchored at visible right endpoint'
    return (left+right)/2,{'method':method,'extent_x_px':[left,right],'precise':False}

manifests=[];all_stats=[];mapping=[];previews=[];seen=[]
for idx,(oi,zi,mi) in enumerate(GROUPS,1):
    case=f'case_{idx:03d}';folder=OUT/case;folder.mkdir(exist_ok=True)
    on,oraw,oa,ometa=image(oi);selected=centers_all[on];op=ometa['pixel_nm']
    params=dict(rows[on]);canonical=PT.canonicalize(params);params.update(canonical)
    params['zoom_line_id']=3 if zi is not None else None;params['scan_pattern']='待确认'
    omask=A.evidence_mask(oa,selected,op,canonical['spacing_um'],sensitivity=1.2)
    ooverlay=R.overlay(oa,omask)
    (folder/'original_overview.tif').write_bytes(oraw)
    (folder/'overview_mask.png').write_bytes(engine.png_bytes(omask))
    (folder/'overview_overlay.png').write_bytes(engine.png_bytes(ooverlay))
    grid,gridmeta=local_grid(omask,op,selected)
    (folder/'overview_psf_grid.png').write_bytes(engine.png_bytes(grid))
    grid_info={'overview':gridmeta}
    zn='';zm=None;za=None;zmeta=None;zraw=None;zc=None
    seen.append(on)
    if zi is not None:
        zn,zraw,za,zmeta=image(zi);zp=zmeta['pixel_nm'];zc=ZOOM_CENTERS[zi]
        zm=A.evidence_mask(za,[zc],zp,None,sensitivity=1.2,max_halfwidth_nm=350)
        (folder/'original_zoom.tif').write_bytes(zraw)
        (folder/'zoom_mask.png').write_bytes(engine.png_bytes(zm))
        (folder/'zoom_overlay.png').write_bytes(engine.png_bytes(R.overlay(za,zm)))
        zgrid,zgm=local_grid(zm,zp,[zc]);grid_info['zoom']=zgm
        (folder/'zoom_psf_grid.png').write_bytes(engine.png_bytes(zgrid))
        seen.append(zn)
    mn,mraw,ma,mmeta=image(mi);(folder/'original_measurement.tif').write_bytes(mraw);seen.append(mn)
    # Parameter identity and stage position support a candidate pairing, never a
    # claim that the zoom corresponds to a known numbered overview line.
    used=[on]+([zn] if zn else [])+[mn]
    param_per_image={n:{'original':original_records[n], 'effective':rows[n],
                          'canonical_effective':PT.canonicalize(rows[n])} for n in used}
    jwrite(folder/'parameters_by_image.json',param_per_image)
    conflict=[n for n in used if PT.canonicalize(rows[n])!=canonical]
    locating={'status':'no zoom provided','score':0,'box':None}
    roi_candidates=[]
    if zi:
        locating=A.auto_locate(oa,za,op,zp)
        for k,y in enumerate(selected,1):
            box=PH.line_based_roi(oa,za,op,zp,y,overview_mask=omask,zoom_field_height=za.shape[0])
            roi_candidates.append({'line_index':k,'xyxy_overview_px':list(box['box']),
                'method':'physical field size; horizontal midpoint hypothesis',
                'verified':False})
    feature_roi=list(locating['box']) if locating.get('box') else None
    roi=None
    if zi:
        computed=PH.line_based_roi(oa,za,op,zp,selected[2],overview_mask=omask,zoom_field_height=za.shape[0])
        # User confirms that the imaged structure is at the midpoint of line 3.
        # Align the observed zoom ridge, rather than the zoom image's geometric
        # center, to that overview point. Pixel scale comes from each TIFF.
        midpoint_x,midpoint_details=line_midpoint(oa,selected,op,canonical['line_length_um'])
        x0=int(np.clip(round(midpoint_x-computed['width_px']/2),0,oa.shape[1]-computed['width_px']))
        y0=int(np.clip(round(selected[2]-zc*zp/op),0,oa.shape[0]-computed['height_px']))
        roi=[x0,y0,x0+computed['width_px'],y0+computed['height_px']]
        roi_candidates=[{'line_index':3,'xyxy_overview_px':roi,
             'method':'user-confirmed third line midpoint; field size and ridge offset from independently calibrated TIFFs',
             'correspondence_confirmed_by_user':True,'exact_feature_registration_verified':False}]
    ostats=M.line_measurements(omask,selected,op)
    zstats=M.line_measurements(zm,[zc],zp) if zi else []
    review={
        'overview':on,'zoom':zn,'measurement':mn,'params':params,
        'pairing':'按工艺参数、倍率、成像内容和采集信息生成候选；未经实验人员确认',
        'spacing_um':canonical['spacing_um'],'design_count':len(selected),'centers':selected,
        'line_ranges':{str(k):[0,100] for k in range(len(selected))},
        'zoom_roi_xyxy':roi,'zoom_roi_verified':False,
        'segmentation_mode':'V7.5 真实响应分割（保留断裂）自动候选',
        'overview_nm_per_px':op,'zoom_nm_per_px':zp if zi else None,
        'status':'自动候选，待实验人员复核','parameters_verified':False,'pairing_verified':False,
        'parameters_source_checked':True,'parameters_consistent_across_case':not conflict,
        'overview_line_stats':ostats,'zoom_line_stats':zstats,
        'calibration_source':'SEM TIFF Image Pixel Size; independently read for each original',
        'crop_xyxy_raw_px':[0,0,oa.shape[1],oa.shape[0]],
        'original_image_shape_yx':[ometa['height_px'],ometa['width_px']],
        'segmentation_settings':{'sensitivity':1.2,'min_length_px':7,'overview_max_halfwidth_nm':450,'zoom_max_halfwidth_nm':350,'invert':False,'gap_bridging':False},
        'feature_matching':locating,'feature_roi_candidate':feature_roi,'zoom_roi_candidates':roi_candidates,
        'zoom_line_id':3 if zi else None,
        'zoom_correspondence_confirmed_by_user':bool(zi),
        'zoom_location_source':'用户明确确认：放大的结构都位于第三条线的中间' if zi else None,
        'zoom_roi_method':'第三条线中部；视野按双图TIFF刻度换算，按放大图亮响应中心校正纵向偏移；非特征精确配准' if zi else None,
        'zoom_horizontal_midpoint_details':midpoint_details if zi else None,
        'annotation_reference_labels_nm':REFERENCE_LABELS[idx],
        'annotation_reference_note':'Manually transcribed labels from the supplied measurement image; local annotations may describe different edges or outer feature widths. Not used as global mask width.',
        'mask_width_note':'Stats are widths of the automatic bright-response mask, not independently validated physical material boundaries.',
        'coordinate_conventions':{'image':'x right, y down; cropped at y=1419 without rescaling',
             'dxf':'micrometers; x=x_px*nm/1000; y=(height-1-y_px)*nm/1000; local bottom-left origin',
             'stage':'SEM stage metadata retained, not a verified laser-writing coordinate transform'},
        'design_path_note':'Alternating nominal geometric path; real scan direction and temporal order are unknown.',
        'design_count_note':'Four observed line candidates; not independent confirmation of design or exposure history',
    }
    if idx==15:review['parameter_correction']={'file':'1-45.tif','field':'fs_power_mw','original':0.443,'effective':0.515,'authority':'user confirmation in this conversation: all images in the group are 0.515 mW'}
    if idx==8:review['stage_position_warning']='Overview and zoom SEM stage coordinates differ (~7.6 um in Y); do not infer registration from stage alone.'
    if idx==1:review['missing_files']=['No corresponding high-magnification image was supplied for the 0 mW / 2.12 mW case. 1-03.tif is the annotated overview, not a zoom.']
    jwrite(folder/'review.json',review)
    model=ME.review_to_model_record(idx,review,engine.png_bytes(omask),engine.png_bytes(zm) if zi else None)
    model['mask_quality']='automatic_bright_response_candidate_not_independent_ground_truth'
    model['coordinate_convention']='SEM: x right,y down; DXF: x=x_px*nm/1000, y=(height-1-y_px)*nm/1000; local bottom-left origin, stage transform unknown'
    model['parameters_source_checked']=True
    model['zoom_correspondence_confirmed_by_user']=bool(zi)
    model['zoom_location_source']=review['zoom_location_source']
    model['zoom_roi_method']=review['zoom_roi_method']
    if idx==15:model['parameter_correction']=review['parameter_correction']
    extra=['automatic_mask_needs_review','design_count_inferred_from_visible_candidates','nominal_scan_direction_unverified']
    if conflict:extra.append('cross_image_parameter_conflict')
    if idx==8:extra.append('overview_zoom_stage_positions_differ')
    if idx==1:extra.extend(['missing_high_magnification_image','annotated_measurement_is_overview'])
    model['needs_review']=list(dict.fromkeys(model['needs_review']+extra))
    model['ready_for_registration']=False;model['ready_for_training']=False
    model['zoom_roi_candidates']=roi_candidates
    jwrite(folder/'model_input.json',model);manifests.append(model)
    jwrite(folder/'grid_metadata.json',grid_info)
    jwrite(folder/'roi_candidates.json',{'feature_match':locating,'user_confirmed_third_line_midpoint':bool(zi),'chosen_region':roi,'regions':roi_candidates,'note':'Correspondence is supplied by the user. Pixel box is a calibrated geometric estimate, not independently verified feature registration.'})
    (folder/'observed_contours_and_design_path.dxf').write_bytes(A.dxf_observed(omask,op,selected,design_length_um=canonical['line_length_um'],spacing_um=canonical['spacing_um']))
    case_stats=[]
    for mag,items,nm in [('overview',ostats,op),('zoom',zstats,zp if zi else None)]:
        for st in items:
            r={'case_id':case,'view':mag,'nm_per_pixel':nm,**st,'status':'automatic_candidate'}
            case_stats.append(r);all_stats.append(r)
    cwrite(folder/'line_measurements.csv',case_stats)
    # Human-readable review picture with all source roles and candidate masks.
    preview=Image.new('RGB',(1600,1180),'white');draw=ImageDraw.Draw(preview)
    title=f'{case} | 517 nm={canonical["fs_power_mw"]} mW | 671 nm={canonical["cw_power_mw"]} mW | v={canonical["speed_um_s"]} um/s'
    draw.text((20,12),title,fill='black',font_size=24)
    panels=[(on+' | original overview',oa),(on+' | automatic mask overlay',ooverlay),
            ((zn or 'NO ZOOM')+' | original zoom',za),('automatic zoom mask overlay',R.overlay(za,zm) if zi else None)]
    for pi,(label,arr) in enumerate(panels):
        x=20+(pi%2)*800;y=55+(pi//2)*555
        draw.text((x,y),label,fill='black',font_size=20)
        if arr is not None:
            pic=Image.fromarray(arr).convert('RGB');pic.thumbnail((760,520));preview.paste(pic,(x,y+30))
        else:draw.text((x,y+60),'No high-magnification input supplied.',fill='red',font_size=23)
    preview.save(folder/'preview.jpg',quality=88);previews.append(preview.copy())
    roipic=Image.fromarray(oa).convert('RGB');rd=ImageDraw.Draw(roipic)
    for candidate in roi_candidates:
        rd.rectangle(candidate['xyxy_overview_px'],outline=(255,70,25),width=4)
        x,y,_,_=candidate['xyxy_overview_px'];rd.text((x,y-30),'L3 midpoint (user confirmed)',fill=(255,130,0),font_size=24)
    if roi:rd.rectangle(roi,outline=(255,30,30),width=5)
    roipic.save(folder/'roi_candidates_overview.png')
    for role,n,meta in [('overview',on,ometa),('zoom',zn,zmeta),('measurement',mn,mmeta)]:
        if not n:continue
        mapping.append({'case_id':case,'role':role,'original_filename':n,'output_filename':'original_'+role+'.tif',
                        'pixel_nm':meta['pixel_nm'],'stage_x_mm':meta['stage_x_mm'],'stage_y_mm':meta['stage_y_mm'],
                        'sha256':hashlib.sha256((RAW/n).read_bytes()).hexdigest(),
                        **PT.canonicalize(rows[n]),'corrected':n=='1-45.tif'})
    print(case,on,zn,mn,'match:',locating['status'],'mask_px:',int(np.count_nonzero(omask)),int(np.count_nonzero(zm)) if zi else 0,flush=True)

# Preserve the context image, with no invented processing parameters or group.
context=OUT/'context';context.mkdir(exist_ok=True)
shutil.copy2(RAW/'1-01.tif',context/'original_context.tif')
jwrite(context/'metadata.json',{'filename':'1-01.tif',**engine.metadata_of((RAW/'1-01.tif').read_bytes()),'role':'low magnification context','parameters':None,'needs_review':['missing_process_parameters','not_a_single_case_overview']})
seen.append('1-01.tif')
assert sorted(seen)==sorted(p.name for p in RAW.glob('*.tif')) and len(seen)==45
sources=OUT/'sources';sources.mkdir(exist_ok=True)
shutil.copy2(XLS,sources/'process_parameters_original.xlsx')
wb=openpyxl.load_workbook(XLS)
for cells in wb['数据填写'].iter_rows(min_row=2):
    if cells[1].value=='1-45.tif':cells[4].value=0.515
audit=wb.create_sheet('本次用户确认修正')
audit.append(['文件','字段','原值','采用值','依据']);audit.append(['1-45.tif','517 nm功率 (mW)',0.443,0.515,'用户确认：这一组均为0.515 mW；原表文件另存未改'])
wb.save(sources/'process_parameters_corrected.xlsx')
changes=[{'file':'1-45.tif','field':'fs_power_mw','original':0.443,'effective':0.515,'authority':'user confirmation'}]
jwrite(OUT/'parameter_corrections.json',changes)
shutil.copy2(ROOT/'inspection/contact.jpg',OUT/'all_45_images_contact.jpg')
shutil.copy2(ROOT/'inspection/metadata.json',OUT/'all_image_metadata.json')
for n in ['SEM_AutoCAD_Tool_v7_5.zip','case_002.zip']:
    p=next(Path('/workspace/attachments').rglob(n));shutil.copy2(p,sources/('reference_example_case_002.zip' if n=='case_002.zip' else n))
cwrite(OUT/'file_mapping.csv',mapping)
cwrite(OUT/'line_measurements.csv',all_stats)
jwrite(OUT/'colab_model_manifest.json',{'format_version':'7.2-compatible-candidate-export','cases':manifests})
mf=['case_id','dataset_id','status','overview_file','zoom_file','measurement_file','overview_pixel_nm','zoom_pixel_nm','fs_power_mw','cw_power_mw','speed_um_s','spacing_um','line_length_um','n_lines','zoom_line_id','scan_pattern_recorded','parameters_verified','pairing_verified','zoom_roi_verified','ready_for_registration','ready_for_training','needs_review']
cwrite(OUT/'colab_model_manifest.csv',manifests,mf)
summary=[]
for m in manifests:
    summary.append({'组号':m['case_id'],'整体图':m['overview_file'],'放大图':m['zoom_file'],'测量图':m['measurement_file'],
        '517nm功率(mW)':m['fs_power_mw'],'671nm功率(mW)':m['cw_power_mw'],'扫描速度(um/s)':m['speed_um_s'],
        '线间距(um)':m['spacing_um'],'设计线长(um)':m['line_length_um'],'检测线数':m['n_lines'],
        '整体nm/px':m['overview_pixel_nm'],'放大nm/px':m['zoom_pixel_nm'],
        '放大区域已确认':False,'人工已确认':False,'可用于训练':False,
        '待复核':'; '.join(m['needs_review'])})
cwrite(OUT/'reviewed_summary.csv',summary)
workbook=openpyxl.Workbook();sheet=workbook.active;sheet.title='分组与工艺参数'
for name,rs in [('分组与工艺参数',summary),('图像文件映射',mapping),('候选掩膜线宽',all_stats),('用户确认修正',changes)]:
    sh=sheet if name=='分组与工艺参数' else workbook.create_sheet(name)
    fields=list(dict.fromkeys(k for r in rs for k in r));sh.append(fields)
    for r in rs:sh.append([json.dumps(r.get(k),ensure_ascii=False) if isinstance(r.get(k),(dict,list)) else r.get(k) for k in fields])
    sh.freeze_panes='A2';sh.auto_filter.ref=sh.dimensions
    for cell in sh[1]:cell.fill=PatternFill('solid',fgColor='174B63');cell.font=Font(color='FFFFFF',bold=True)
    for col in sh.columns:sh.column_dimensions[col[0].column_letter].width=min(60,max(16,max(len(str(c.value or '')) for c in list(col)[:30])+2))
    for row in sh:
        for cell in row:cell.alignment=Alignment(vertical='top',wrap_text=True)
notes=workbook.create_sheet('说明')
for note in [
 '45张原始TIFF全部保留：15个候选实验组使用44张，另1张低倍全景保存在context。',
 '掩膜线宽为自动亮响应掩膜宽度，非独立实测材料边界；不替代SEM原有标注。',
 'case_001缺少放大图，1-03是带标注的整体图。',
 'case_015功率按用户确认统一0.515mW；原表1-45为0.443，原表另存保留。',
 '用户已确认放大结构在第三条线中间；掩膜和扫描方式待复核，ready_for_training=false。',
 'PSF文件名沿用样例，仅为20nm局部二值掩膜网格，不是实测或计算的光学PSF。',
 'DXF单位微米，局部左下原点；整体与放大图各自独立读取TIFF像素尺寸。',
 'case_008整体与放大图Stage Y不同，区域与线号必须另行确认。',
 '分组依据文件名、参数、图像内容和采集元数据综合候选，不按文件顺序盲目配对。',
]:notes.append([note])
notes.column_dimensions['A'].width=120
for row in notes:row[0].alignment=Alignment(wrap_text=True)
workbook.save(OUT/'SEM_summary.xlsx')
contact=Image.new('RGB',(1500,5*570),'white')
for i,pic in enumerate(previews):
    pic.thumbnail((495,565));contact.paste(pic,((i%3)*500,(i//3)*570))
contact.save(OUT/'all_cases_preview.jpg',quality=90)
links=[]
for m in manifests:
    c=m['case_id'];links.append(f'<article><h2>{c}: {html.escape(m["overview_file"])} / {html.escape(m["zoom_file"] or "缺少放大图")}</h2><p>517 nm {m["fs_power_mw"]} mW；671 nm {m["cw_power_mw"]} mW；速度 {m["speed_um_s"]} µm/s</p><a href="{c}/preview.jpg"><img loading="lazy" src="{c}/preview.jpg"></a><p><a href="{c}/review.json">审核信息</a> · <a href="{c}/model_input.json">模型输入清单</a> · <a href="{c}/observed_contours_and_design_path.dxf">DXF</a> · <a href="{c}/roi_candidates_overview.png">放大区域候选</a></p></article>')
(OUT/'index.html').write_text('<!doctype html><html lang="zh"><meta charset="utf-8"><title>SEM结果浏览</title><style>body{font:16px system-ui;max-width:1150px;margin:30px auto;padding:0 18px;background:#f4f7fa;color:#153449}article{background:white;padding:18px;margin:24px 0;border-radius:10px}img{width:100%}a{color:#006e98}</style><h1>SEM批处理结果：15组 / 45张原图</h1><p>自动候选结果，待实验人员复核。PSF命名文件为局部掩膜网格，并非光学PSF。解压后可直接打开此文件浏览。</p><p><a href="SEM_summary.xlsx">Excel汇总</a> · <a href="README_使用说明.txt">使用说明</a> · <a href="all_45_images_contact.jpg">全部原图缩略图</a></p>'+''.join(links)+'</html>',encoding='utf-8')
print('EXPORT COMPLETE',len(manifests),len(seen),flush=True)
