"""Update ROI geometry only; do not rerun or change segmentation."""
from pathlib import Path
import json,numpy as np
from PIL import Image,ImageDraw
import engine
# Read just the standalone midpoint helper, not the top-level batch driver.
import ast
from scipy import ndimage as ndi
source=(Path(__file__).parent/'batch_export.py').read_text()
tree=ast.parse(source)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='line_midpoint')
exec(compile(ast.Module(body=[node],type_ignores=[]),'midpoint_helper','exec'))
base=Path('/workspace/sem_results/SEM_results');work=Path('/workspace/sem_work')
for folder in sorted(base.glob('case_*')):
    if not folder.is_dir():continue
    p=folder/'review.json';r=json.loads(p.read_text())
    if not r['zoom']:continue
    a=engine.grayscale_image((folder/'original_overview.tif').read_bytes())
    cx,details=line_midpoint(a,r['centers'],r['overview_nm_per_px'],r['params']['line_length_um'])
    old=r['zoom_roi_xyxy'];width=old[2]-old[0];left=int(np.clip(round(cx-width/2),0,a.shape[1]-width))
    new=[left,old[1],left+width,old[3]]
    r['zoom_roi_xyxy']=new;r['zoom_roi_candidates'][0]['xyxy_overview_px']=new;r['zoom_horizontal_midpoint_details']=details
    p.write_text(json.dumps(r,ensure_ascii=False,indent=2))
    mp=folder/'model_input.json';m=json.loads(mp.read_text())
    m['zoom_roi_xyxy_overview_px']=[float(q) for q in new];m['zoom_roi_candidates']=r['zoom_roi_candidates'];m['zoom_horizontal_midpoint_details']=details
    mp.write_text(json.dumps(m,ensure_ascii=False,indent=2))
    rp=folder/'roi_candidates.json';v=json.loads(rp.read_text());v['chosen_region']=new;v['regions']=r['zoom_roi_candidates'];v['midpoint_details']=details;rp.write_text(json.dumps(v,ensure_ascii=False,indent=2))
    pic=Image.fromarray(a).convert('RGB');d=ImageDraw.Draw(pic)
    d.rectangle(new,outline=(255,40,25),width=5);d.text((new[0],new[1]-30),'L3 midpoint (user confirmed)',fill=(255,130,0),font_size=24)
    pic.save(folder/'roi_candidates_overview.png')
    print(folder.name,new,details)
manifest=json.loads((base/'colab_model_manifest.json').read_text())
manifest['cases']=[json.loads((base/m['case_id']/'model_input.json').read_text()) for m in manifest['cases']]
(base/'colab_model_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
# Make the contact view compact while preserving individual preview images.
canvas=Image.new('RGB',(1500,5*390),'white')
for i,p in enumerate(sorted(base.glob('case_*/preview.jpg'))):
    im=Image.open(p);im.thumbnail((495,375));canvas.paste(im,((i%3)*500,(i//3)*390))
canvas.save(base/'all_cases_preview.jpg',quality=90)
