Step 12.7 compatible CANDIDATE manifest.
User confirms zoom structure is at the midpoint of overview line 3.
Do not use as registered 8-channel model-ready data.
Masks are automatic bright-response candidates, not human-reviewed labels.
PSF-named PNGs are local binary mask resampling only, not optical PSFs.
Real scan order, temporal exposure history, physical material boundaries, image-to-writing-coordinate registration, measured optical PSF and PDE remain unverified.
Case 001 lacks a high-magnification image.
See README_使用说明.txt and needs_review.
